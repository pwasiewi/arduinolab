var searchData=
[
  ['handler_5fstack_5fsize',['HANDLER_STACK_SIZE',['../_ch_rt_8h.html#acdb3e86f36ba7ea83d508e406d29dca1',1,'ChRt.h']]],
  ['heapend',['heapEnd',['../_ch_rt_8h.html#a9a1425ec66529dd4aec14702b02451d2',1,'ChRt.cpp']]]
];
