var searchData=
[
  ['handler_5fstack_5fsize',['HANDLER_STACK_SIZE',['../_ch_rt_8h.html#acdb3e86f36ba7ea83d508e406d29dca1',1,'ChRt.h']]]
];
